package com.example.chimes;


import android.support.v7.app.AppCompatActivity;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class SilentModeActivity extends AppCompatActivity {
    private TextToSpeech mTTS;
    private Button mSilentLocationSpeak;
    private Button mSilentNorthSpeak;
    private Button mSilentChimeSpeak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_silent_mode);

        mSilentLocationSpeak = findViewById(R.id.button_silentlocation);
        mSilentNorthSpeak = findViewById(R.id.button_silentnorth);
        mSilentChimeSpeak = findViewById(R.id.button_silentchime);

        //TTS for buttons
        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.US);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                        //CAN I ENABLE ALL THREE HERE???**********
                        mSilentLocationSpeak.setEnabled(true);
                        mSilentNorthSpeak.setEnabled(true);
                        mSilentChimeSpeak.setEnabled(true);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

        //listens for Location button to be pressed
        mSilentLocationSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = "Location";
                speak(text);
            }
        });
        //listens for North button to be pressed
        mSilentNorthSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = "North";
                speak(text);
            }
        });
        mSilentChimeSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = "Chime";
                speak(text);
            }
        });
    }//end of onCreate

    //called when want app to speak, text is whatever the app is saying
    private void speak(String text) {
        float pitch = 1; //1.0 is normal pitch
        float speed = 1; //normal speech 1.0

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);
        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override //override this method and destroy mTTS when done w it
    protected void onDestroy() {
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }
}

