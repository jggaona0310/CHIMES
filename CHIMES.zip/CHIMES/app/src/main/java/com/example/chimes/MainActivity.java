package com.example.chimes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Button;


import java.util.Locale;

public class MainActivity extends AppCompatActivity{
    private TextToSpeech mTTS;
    private Button mAudibleMode;
    private Button mSilentMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAudibleMode = findViewById(R.id.button_audiblemode);
        mSilentMode = findViewById(R.id.button_silentmode);

        //TTS for Location button
        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.US);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                        mAudibleMode.setEnabled(true);
                        mSilentMode.setEnabled(true);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

        //speak when CHIMES app is opened
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mTTS.speak("Welcome to CHIMES. Please select either Silent Mode or Audible Mode", TextToSpeech.QUEUE_FLUSH, null);
            }
        }, 100);

    }//end of onCreate

    //Called when Silent Mode Button is selected
    public void silentMode(View view) { //(onClick)
        Intent silentMode = new Intent(this, SilentModeActivity.class);
        //add settings as an extra for the intent - next page could use key for data
        startActivity(silentMode);

        String text = "Silent Mode Activated";
        speak(text);
    }

    //Called when Audible Mode Button is selected
    public void audibleMode(View view) {
        Intent audibleMode = new Intent(this, AudibleModeActivity.class);
        //add settings as an extra for the intent - next page could use key for data
        startActivity(audibleMode);

        String text = "Audible Mode Activated";
        speak(text);
    }

    //called when want app to speak, text is whatever the app is saying
    private void speak(String text) {
        float pitch = 1; //1.0 is normal pitch
        float speed = 1; //normal speech 1.0

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);
        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override //override this method and destroy mTTS when done w it
    protected void onDestroy() {
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }
}
